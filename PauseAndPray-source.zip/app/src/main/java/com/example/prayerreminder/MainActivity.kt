package com.example.prayerreminder

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val intervalOptions = listOf(15L, 30L, 60L, 120L)
    private val intervalLabels = listOf("Every 15 minutes", "Every 30 minutes", "Every hour", "Every 2 hours")

    private lateinit var statusText: TextView
    private lateinit var intervalSpinner: Spinner

    private val notificationPermissionRequestCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        intervalSpinner = findViewById(R.id.intervalSpinner)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, intervalLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        intervalSpinner.adapter = adapter

        val savedMinutes = Prefs.getIntervalMinutes(this)
        val savedIndex = intervalOptions.indexOf(savedMinutes).let { if (it == -1) 1 else it }
        intervalSpinner.setSelection(savedIndex)

        findViewById<Button>(R.id.startButton).setOnClickListener { startReminders() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopReminders() }
        findViewById<Button>(R.id.testButton).setOnClickListener { sendTestReminder() }
        findViewById<Button>(R.id.permissionButton).setOnClickListener { requestExactAlarmPermission() }

        requestNotificationPermissionIfNeeded()
        updateStatus()
    }

    private fun updateStatus() {
        statusText.text = if (Prefs.isEnabled(this)) {
            "Reminders are ON — every ${intervalLabels[intervalOptions.indexOf(Prefs.getIntervalMinutes(this)).coerceAtLeast(0)]}"
        } else {
            "Reminders are off"
        }
    }

    private fun startReminders() {
        val minutes = intervalOptions[intervalSpinner.selectedItemPosition]
        Prefs.setIntervalMinutes(this, minutes)
        Prefs.setEnabled(this, true)
        AlarmScheduler.scheduleNext(this, minutes)
        updateStatus()
        Toast.makeText(this, "Reminders started — every $minutes min", Toast.LENGTH_SHORT).show()
    }

    private fun stopReminders() {
        Prefs.setEnabled(this, false)
        AlarmScheduler.cancel(this)
        updateStatus()
        Toast.makeText(this, "Reminders stopped", Toast.LENGTH_SHORT).show()
    }

    private fun sendTestReminder() {
        NotificationHelper.showReminder(this)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    notificationPermissionRequestCode
                )
            }
        }
    }

    private fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, "Exact alarms already enabled", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Not needed on this Android version", Toast.LENGTH_SHORT).show()
        }
    }
}
