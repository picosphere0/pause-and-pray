package com.example.prayerreminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {
    private const val CHANNEL_ID = "prayer_reminders"
    private const val NOTIFICATION_ID_BASE = 5000

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Prayer Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Reminders to pray, read scripture, and breathe."
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    fun showReminder(context: Context) {
        ensureChannel(context)

        val verses = context.resources.getStringArray(R.array.verses)
        val index = Prefs.nextVerseIndex(context, verses.size)
        val parts = verses[index].split("|")
        val verse = parts.getOrElse(0) { "" }
        val ref = parts.getOrElse(1) { "" }
        val line = parts.getOrElse(2) { "" }

        val message = "\"$verse\" — $ref\n\n$line"

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pause & Pray 🙏")
            .setContentText(line)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        val id = NOTIFICATION_ID_BASE + (System.currentTimeMillis() % 1000).toInt()
        try {
            NotificationManagerCompat.from(context).notify(id, notification)
        } catch (e: SecurityException) {
            // Notification permission not granted (Android 13+). MainActivity handles requesting it.
        }
    }
}
