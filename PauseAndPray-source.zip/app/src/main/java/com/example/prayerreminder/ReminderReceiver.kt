package com.example.prayerreminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Prefs.isEnabled(context)) return

        NotificationHelper.showReminder(context)

        // Re-schedule the next one to keep the chain going (self-rescheduling alarm).
        val minutes = Prefs.getIntervalMinutes(context)
        AlarmScheduler.scheduleNext(context, minutes)
    }
}
