package com.example.prayerreminder

import android.content.Context

object Prefs {
    private const val NAME = "prayer_reminder_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_INTERVAL = "interval_minutes"
    private const val KEY_VERSE_INDEX = "verse_index"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun getIntervalMinutes(context: Context): Long =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getLong(KEY_INTERVAL, 30L)

    fun setIntervalMinutes(context: Context, minutes: Long) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putLong(KEY_INTERVAL, minutes).apply()
    }

    fun nextVerseIndex(context: Context, size: Int): Int {
        val prefs = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        val current = prefs.getInt(KEY_VERSE_INDEX, 0)
        val next = (current + 1) % size
        prefs.edit().putInt(KEY_VERSE_INDEX, next).apply()
        return current
    }
}
