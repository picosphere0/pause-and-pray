# Pause & Pray — Android Reminder App

Reminds you to pray, read a short Bible verse (KJV), breathe, and turn away from
lust — on a repeating schedule (15 min / 30 min / 1 hr / 2 hr, your choice).

## How to get the APK (all from your phone, no computer needed)

1. **Create a new GitHub repo** (github.com → "+" → New repository). Public or
   private both work. Name it anything, e.g. `pause-and-pray`.
2. **Upload this whole folder's contents** into that repo, preserving the
   folder structure exactly (including the hidden `.github/workflows/build.yml`
   file — GitHub's web uploader shows hidden folders fine once you drag the
   whole zip in, or use the GitHub app's "Add file → Upload files").
3. Once pushed, go to the **Actions** tab in your repo. A workflow called
   "Build APK" should start automatically. Give it a few minutes.
4. When it finishes (green checkmark), open that run and scroll to
   **Artifacts** — download `PauseAndPray-debug-apk`. It's a zip containing
   `app-debug.apk`.
5. On your phone, extract the zip (most file manager apps can do this, or
   use an app like "Files" / "ZArchiver"), then tap `app-debug.apk` to
   install it. Android will ask you to allow "install unknown apps" for
   whichever app you used to open it — allow it, then install.

## First-time setup in the app

1. Open **Pause & Pray**.
2. It'll ask for notification permission — allow it.
3. Tap **Enable exact alarms** once — this opens a system settings screen;
   turn the toggle on for this app. (Needed on Android 12+ so reminders fire
   on time even when the screen is off.)
4. Pick your interval from the dropdown and tap **Start reminders**.
5. Tap **Send test reminder now** to confirm it works right away.

## How it works

- Uses `AlarmManager` with a self-rescheduling chain: each reminder fires,
  shows a notification, and schedules the next one — so it keeps going
  indefinitely without drift.
- A `BootReceiver` restarts the chain automatically if you reboot your phone.
- Verses rotate through a fixed list (Psalm 46:10, 1 Thessalonians 5:17,
  2 Timothy 2:22, Matthew 26:41, Philippians 4:8, Psalm 23:1, Psalm 51:10) —
  each paired with a short "breathe / pray / turn away" prompt.

## Notes

- This is a **debug build** — fine for installing on your own phone, not
  meant for the Play Store.
- If Android ever kills the alarm chain (some phones aggressively manage
  battery), just reopen the app and tap **Start reminders** again.
